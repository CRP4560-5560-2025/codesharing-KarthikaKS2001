#Author: Karthika Kolengattukara Suresh
#Date Created: November 27, 2025

#Purpose of the Code: This project contains a Python toolbox that reads census data for Story County. I have used the total percentage of households with grandparents living with grandchildren data. Here, the toolbox converts a GeoJSON file of census tracts into a feature class, joins it with a cleaned census CSV file, displays the joined data on the map using different symbology options, and creates a simple graph of the same census variable using matplotlib.

#Data Accessed
1. Census Tracts GeoJSON - With grandparents living with grandchildren - Total | Households | HOUSEHOLDS
Downloaded from data.census.gov using “Advanced Search → Geography → Census Tracts → Story County, Iowa”

2. Census CSV Table - With grandparents living with grandchildren - Total | Households | HOUSEHOLDS
Cleaned in Excel. Contains three fields:
NAME – example: “Census Tract 1.01”
TotalHHwithgrandparentslivingwithgrandchildren - which has the % symbol along with the values
PercentageofHHwithgrandparentswithgrandchildren – numeric census estimate (without the % symbol)

(Any other census field can be used as long as it has a matching NAME join field).

#How to Run the Code Package 

1.Open the ArcGIS Pro > Map > New Project (Make sure the project has at least one empty map)
2. View > Catalog pane > Right click toolbox > Add toolbox > script1.pyt 
3.Open the tool “Process Census CSV + GeoJSON” from under toolbox
4.Fill in the inputs:
 Select your cleaned CSV file - Assign6Excel.csv 
 Select the GeoJSON of Story County census tracts - Census Tract-2025-11-28T00_32_31.306Z\P504577759-2025-11-2009564883-MapLayer.json
 Choose an output folder 
 Type the join field name: NAME
 Type the census field to map and graph (e.g.,PercentageofHHwithgrandparentswithgrandchildren) - PercentageofHHwithgrandparentswithgrandchildren    (This is the 3rd column name of the excel table)
 Choose a display option (Graduated Colors, Graduated Symbols, or Unique Values) - Graduated colors (preferred)
 Choose where to save the graph PNG
 Click Run.
5.The tool will:
 Create a geodatabase
 Convert GeoJSON → feature class
 Join the CSV table
 Add the layer to the map with chosen symbology
 Save a histogram graph as a PNG