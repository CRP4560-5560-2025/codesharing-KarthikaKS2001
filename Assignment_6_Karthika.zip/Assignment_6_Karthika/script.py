#Author: Karthika Kolengattukara Suresh
#Date: 11/27/2025
#Python version: 3.11
#Purpose: Creating a census toolbox for story county, Iowa

import arcpy
import os
import matplotlib.pyplot as plt

class Toolbox(object):
    def __init__(self):
        self.label = "Story County Census Toolbox"
        self.alias = "storycensus"
        self.tools = [CensusTool]


class CensusTool(object):
    def __init__(self):
        self.label = "Process Census CSV + GeoJSON"
        self.description = ("Converts GeoJSON to a feature class, joins the "
                            "cleaned census CSV, lets the user pick a display "
                            "option, and makes a matplotlib graph.")
        self.canRunInBackground = False

    def getParameterInfo(self):
        #Ask the user to select CSV file
        csv_file = arcpy.Parameter(
            displayName="Census CSV file",
            name="csv_file",
            datatype="DEFile",
            parameterType="Required",
            direction="Input"
        )

        #Ask the user to select GeoJSON file
        geojson_file = arcpy.Parameter(
            displayName="Census GeoJSON file",
            name="geojson_file",
            datatype="DEFile",
            parameterType="Required",
            direction="Input"
        )

        #Ask where to save outputs
        out_folder = arcpy.Parameter(
            displayName="Output folder (for gdb & temp tables)",
            name="out_folder",
            datatype="DEFolder",
            parameterType="Required",
            direction="Input"
        )

        #Ask for JOIN field name (e.g. NAME)
        join_field = arcpy.Parameter(
            displayName="Join field name (in both CSV and GeoJSON)",
            name="join_field",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )

        # field used for map + graph (e.g. PercentageofHHwithgrandparentslivingwithgrandchildren)
        value_field = arcpy.Parameter(
            displayName="Field to map & graph (e.g. PercentageofHHwithgrandparentslivingwithgrandchildren)",
            name="value_field",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )

        #Drop-down menu for display options
        display_option = arcpy.Parameter(
            displayName="Display option for map",
            name="display_option",
            datatype="GPString",
            parameterType="Required",
            direction="Input"
        )
        display_option.filter.type = "ValueList"
        display_option.filter.list = ["Graduated Colors",
                                      "Graduated Symbols",
                                      "Unique Values"]

        #Ask where to save graph PNG
        graph_png = arcpy.Parameter(
            displayName="Output graph PNG",
            name="graph_png",
            datatype="DEFile",
            parameterType="Required",
            direction="Output"
        )

        return [csv_file, geojson_file, out_folder,
                join_field, value_field, display_option, graph_png]

    def execute(self, parameters, messages):

        csv_path      = parameters[0].valueAsText
        geojson_path  = parameters[1].valueAsText
        out_folder    = parameters[2].valueAsText
        join_field    = parameters[3].valueAsText
        value_field   = parameters[4].valueAsText
        display_opt   = parameters[5].valueAsText
        graph_png     = parameters[6].valueAsText

        arcpy.env.workspace = out_folder

        #Convert GeoJSON to feature class 
        gdb_path = os.path.join(out_folder, "story_census.gdb")
        if not arcpy.Exists(gdb_path):
            arcpy.CreateFileGDB_management(out_folder, "story_census.gdb")

        fc_name = "Story_Tracts"
        fc_path = os.path.join(gdb_path, fc_name)

        arcpy.AddMessage("Converting GeoJSON to feature class...")
        arcpy.conversion.JSONToFeatures(geojson_path, fc_path)

        #bring CSV in as a table 
        arcpy.AddMessage("Copying CSV to table...")
        csv_table = os.path.join(gdb_path, "census_table")
        arcpy.conversion.TableToTable(csv_path, gdb_path, "census_table")

        #Join on user-specified join_field 
        arcpy.AddMessage(f"Joining on field: {join_field}")
        arcpy.management.JoinField(fc_path, join_field,
                                   csv_table, join_field)

        #Add to current map and apply symbology 
        aprx = arcpy.mp.ArcGISProject("CURRENT")
        m = aprx.activeMap
        # if there is no active map, use the first map in the project
        if m is None:
            maps = aprx.listMaps()
            if len(maps) == 0:
                raise Exception("No maps found in the current project.")
            m = maps[0]

        lyr = m.addDataFromPath(fc_path)


        sym = lyr.symbology

        if display_opt == "Graduated Colors":
            sym.updateRenderer("GraduatedColorsRenderer")
            sym.renderer.classificationField = value_field

        elif display_opt == "Graduated Symbols":
            sym.updateRenderer("GraduatedSymbolsRenderer")
            sym.renderer.classificationField = value_field

        elif display_opt == "Unique Values":
            sym.updateRenderer("UniqueValueRenderer")
            sym.renderer.fields = [value_field]

        lyr.symbology = sym
        arcpy.AddMessage("Layer added with chosen symbology.")

        #Make matplotlib graph based on same field
        arcpy.AddMessage("Building matplotlib graph...")

        values = []
        with arcpy.da.SearchCursor(fc_path, [value_field]) as cursor:
            for (v,) in cursor:
                if v is None:
                    continue
                try:
                    # handle values like "0.90%" if you left the % in
                    if isinstance(v, str) and "%" in v:
                        v = float(v.replace("%", ""))   # just number
                    values.append(float(v))
                except:
                    continue

        plt.figure(figsize=(8, 5))
        plt.hist(values, bins=15)
        plt.title(f"Distribution of {value_field}")
        plt.xlabel(value_field)
        plt.ylabel("Frequency")
        plt.tight_layout()
        plt.savefig(graph_png, dpi=300)
        plt.close()

        arcpy.AddMessage(f"Graph saved to: {graph_png}")

